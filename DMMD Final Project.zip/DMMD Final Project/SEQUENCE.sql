

CREATE SEQUENCE SEQ_CUSTOMER_RK
start with 1
increment by 1
nocache 
nocycle
;


CREATE SEQUENCE SEQ_ADDRESS_ID
start with 1
increment by 1
nocache 
nocycle
;

CREATE SEQUENCE SEQ_PAYMENT_ID
start with 1
increment by 1
nocache 
nocycle
;

CREATE SEQUENCE SEQ_REVIEW_ID
start with 1
increment by 1
nocache 
nocycle
;

CREATE SEQUENCE SEQ_ORDER_ID
start with 1
increment by 1
nocache 
nocycle
;

CREATE SEQUENCE SEQ_LINE_ID
start with 1
increment by 1
nocache 
nocycle
;


CREATE SEQUENCE SEQ_CAT_ID
start with 1
increment by 1
nocache 
nocycle
;


CREATE SEQUENCE SEQ_PROD_ID
start with 1
increment by 1
nocache 
nocycle
;

CREATE SEQUENCE SEQ_VENDOR_ID
start with 1
increment by 1
nocache 
nocycle
;


CREATE SEQUENCE SEQ_VEND_ADDR_ID
start with 1
increment by 1
nocache 
nocycle
;
